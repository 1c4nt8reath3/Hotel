<?php
require_once 'config.php';

requireLogin();

$conn = getDBConnection();
$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT b.id, r.room_number, r.room_type, b.check_in, b.check_out, b.total_price, b.status FROM bookings b JOIN rooms r ON b.room_id = r.id WHERE b.user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$bookings = [];
while ($row = $result->fetch_assoc()) {
    $bookings[] = $row;
}

$stmt->close();
$conn->close();
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Moje Rezerwacje</title>
    <link rel="stylesheet" href="../css/styles.css" />
  </head>
  <body>
    <header>
      <nav>
        <div class="container">
          <h1>Łódźtel</h1>
          <ul>
            <li><a href="../index.html">Strona główna</a></li>
            <li><a href="../book.html">Pokoje</a></li>
            <li><a href="../php/logout.php">Wyloguj</a></li>
          </ul>
        </div>
      </nav>
    </header>

    <main>
      <div class="container">
        <h2>Moje Rezerwacje</h2>
        <?php if (empty($bookings)): ?>
          <p>Nie masz jeszcze żadnych rezerwacji.</p>
        <?php else: ?>
          <table>
            <thead>
              <tr>
                <th>Numer pokoju</th>
                <th>Typ pokoju</th>
                <th>Data zameldowania</th>
                <th>Data wymeldowania</th>
                <th>Cena całkowita</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($bookings as $booking): ?>
                <tr>
                  <td><?php echo htmlspecialchars($booking['room_number']); ?></td>
                  <td><?php echo htmlspecialchars($booking['room_type']); ?></td>
                  <td><?php echo htmlspecialchars($booking['check_in']); ?></td>
                  <td><?php echo htmlspecialchars($booking['check_out']); ?></td>
                  <td><?php echo htmlspecialchars($booking['total_price']); ?> PLN</td>
                  <td><?php echo htmlspecialchars($booking['status']); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </main>

    <footer>
      <div class="container">
        <p>&copy; 2023 Łódźtel. All rights reserved.</p>
      </div>
    </footer>

    <script src="../js/script.js"></script>
  </body>
</html>